Name: Matthew Boughton
Section: 11947
UFL email: m.boughton@ufl.edu
System: Ubuntu 22.04.2 LTS
Compiler: 11.4.0
SFML version: 2.5.1+dfsg-2
IDE: Vscode
Other notes: I used sudo apt-get install libsfml-dev to install sfml
